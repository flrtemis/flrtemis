
import gradio as gr
from AI import Chatbot

# Initialize the chatbot
bot = Chatbot()

# Define a response function
def chatbot_response(user_input):
    return bot.get_response(user_input)

# Set up Gradio interface
iface = gr.Interface(fn=chatbot_response, inputs="text", outputs="text", title="Train Your Chatbot")
iface.launch()
